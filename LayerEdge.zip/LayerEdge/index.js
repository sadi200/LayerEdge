import axios from 'axios';
import chalk from 'chalk';
import Table from 'cli-table3';
import fs from 'fs/promises';

async function readWalletAddresses() {
    try {
        const data = await fs.readFile('address.txt', 'utf-8');
        const addresses = data.split('\n').map(addr => addr.trim()).filter(addr => addr !== '');
        if (addresses.length === 0) {
            throw new Error('File address.txt kosong.');
        }
        return addresses.slice(0, 10);
    } catch (error) {
        console.error(chalk.red(`[ERROR] Gagal membaca file: ${error.message}`));
        process.exit(1);
    }
}

let table;

function createTable(wallets) {
    table = new Table({
        head: [chalk.cyan('WALLET ADDRESS'), chalk.cyan('STATUS'), chalk.cyan('NODE POINT')],
        colWidths: [60, 20, 20],
        style: { border: ['green'] }
    });

    wallets.forEach(wallet => {
        table.push([wallet, chalk.yellow('PENDING'), '-']);
    });

    console.clear();
    console.log(table.toString());
}

function updateTable(wallet, status, nodePoint) {
    const index = table.findIndex(row => row[0] === wallet);
    if (index !== -1) {
        table[index] = [wallet, status, nodePoint];
    }
    console.clear();
    console.log(table.toString());
}

async function startNodePoints(walletAddress) {
    try {
        updateTable(walletAddress, chalk.blue('STARTING'), '-');
        const response = await axios.post('https://dashboard.layeredge.io/api/node-points/start', {
            walletAddress: walletAddress
        });

        if (response.data && response.data.lastStartTime) {
            updateTable(walletAddress, chalk.green('SUCCESS'), `Start: ${response.data.lastStartTime}`);
            return response.data.lastStartTime;
        } else {
            throw new Error('lastStartTime tidak ditemukan dalam response');
        }
    } catch (error) {
        updateTable(walletAddress, chalk.red('FAILED'), '-');
        return null;
    }
}

async function sendNodePoints(walletAddress, lastStartTime) {
    try {
        updateTable(walletAddress, chalk.blue('PROCESSING'), '-');
        const response = await axios.post('https://dashboard.layeredge.io/api/node-points', {
            walletAddress: walletAddress,
            lastStartTime: lastStartTime
        });

        if (response.data && response.data.nodePoints !== undefined) {
            updateTable(walletAddress, chalk.green('SUCCESS'), response.data.nodePoints);
        } else {
            updateTable(walletAddress, chalk.yellow('NO DATA'), '-');
        }
    } catch (error) {
        updateTable(walletAddress, chalk.red('FAILED'), '-');
    }
}

async function processWallets(wallets) {
    for (const wallet of wallets) {
        const lastStartTime = await startNodePoints(wallet);
        if (lastStartTime) {
            await sendNodePoints(wallet, lastStartTime);
        } else {
            updateTable(wallet, chalk.red('FAILED'), '-');
        }
    }
}

async function main() {
    const walletAddresses = await readWalletAddresses();
    createTable(walletAddresses);
    await processWallets(walletAddresses);
}

const intervalTime = 3000;
console.log(chalk.green(`Bot akan berjalan setiap ${intervalTime / 1000} detik...`));
setInterval(main, intervalTime);

main();
